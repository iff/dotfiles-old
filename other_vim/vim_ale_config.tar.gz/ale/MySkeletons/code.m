function <+FILE NAME:s/\.m/()/+>
% \file         <+FILE NAME+>
% \author       <+AUTHOR+> <+EMAIL+>
% \version      $Id$
% \date         <+DATE+> created
% 
<+CURSOR+>
