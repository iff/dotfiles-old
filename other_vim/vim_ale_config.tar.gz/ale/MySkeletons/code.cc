/** 
 * \file         <+FILE NAME+>
 * \author       <+AUTHOR+> <+EMAIL+>
 * \version      $Id$
 * \brief        <+A brief description+>
 * \par Description
 *   <+TODO a brief description+>
 * \date         <+DATE+> created
 */
#include "<+FILE NAME ROOT+>.h"

<+CURSOR+>
