#!/bin/bash
# $Id: $
# File    package.sh
# Author  Alain Lehmann
# Created 2008-09-22
# 
# generate a package file for all my vim scripts
pushd $HOME/.vim
tar cvzf ~/vim_ale_config.tar.gz ale/
popd
