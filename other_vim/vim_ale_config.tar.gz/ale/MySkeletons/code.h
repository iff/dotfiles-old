/** 
 * \file         <+FILE NAME+>
 * \author       <+AUTHOR+> <+EMAIL+>
 * \version      $Id$
 * \brief        <+A brief description+>
 * \par Description
 *   <+TODO a brief description+>
 * \date         <+DATE+> created
 */
#ifndef <+FILE NAME:us/\./_/+>
#define <+FILE NAME:us/\./_/+>

<+CURSOR+>

#endif /* <+FILE NAME:us/\./_/+> */
