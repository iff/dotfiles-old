#!/bin/bash
# Vim Configuration addons
# use the script and configuration contained in this package at your own risk!

# This folder contains addons to vim which I consider to be very useful, 
# including scripts and tips, but also small things found somewhere else
# on the web.
SRC=$HOME/.vim/ale
PKG=$SRC/pkg
VIMROOT=$HOME/.vim

# INSTALLATION
# - all the configuration things (tips and minor things)
(echo so $SRC/ale_helper.vim;
 for i in $SRC/*.vim; do echo so $i; done) > $SRC/vimrc
ln -s $SRC/vimrc $HOME/.vimrc 
ln -s $SRC/vimrc $HOME/.virc 

# -  taglist
popd
pushd $VIMROOT
unzip $PKG/taglist_45.zip
popd;

# - latex-suite
pushd $VIMROOT;
tar xvzf $PKG/latexSuite20060325.tar.gz
popd;

# - cpp code completion
pushd $VIMROOT;
unzip $PKG/omnicppcomplete.zip
popd;

# - genutils
pushd $VIMROOT;
unzip $PKG/genutils-2.4.zip
popd

# - tlib
vim -c ':so %|:q' $PKG/tlib.vba.gz
# - tSkeleton
vim -c ':so %|:q' $PKG/tSkeleton.vba.gz
# - tSkeleton-Sample
pushd $VIMROOT;
unzip $PKG/tSkeleton-Samples.zip
popd
# - copy my templates
pushd $VIMROOT;
cp $SRC/MySkeletons/* skeletons/

# - vcscommand
pushd /tmp
unzip -u $PKG/vcscommand.zip
cd vcscommand
cp -r doc plugin syntax $VIMROOT
popd

# - finally generate the helptags
vim -c ':helptags ~/.vim/doc | :q'
